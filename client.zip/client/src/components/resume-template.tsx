import { ResumeData } from "@shared/schema";

interface ResumeTemplateProps {
  data: ResumeData;
}

export default function ResumeTemplate({ data }: ResumeTemplateProps) {
  return (
    <div id="resumeTemplate" className="bg-white p-8 max-w-[210mm] mx-auto font-['Montserrat',sans-serif]">
      {/* Header/Personal Info */}
      <div className="mb-6 border-b-2 border-[#2F69FF] pb-4">
        <h1 className="text-2xl font-bold text-[#FB316E] mb-1">{data.personalInfo.fullName}</h1>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
          <div className="flex items-center">
            <span className="material-icons text-[#2F69FF] text-sm mr-1">email</span>
            <span>{data.personalInfo.email}</span>
          </div>
          <div className="flex items-center">
            <span className="material-icons text-[#2F69FF] text-sm mr-1">phone</span>
            <span>{data.personalInfo.phone}</span>
          </div>
          <div className="flex items-center">
            <span className="material-icons text-[#2F69FF] text-sm mr-1">location_on</span>
            <span>{data.personalInfo.location}</span>
          </div>
        </div>
      </div>
      
      {/* Professional Summary */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-2 text-[#2F69FF]">Resumo Profissional</h2>
        <p className="text-neutral-700">{data.personalInfo.profile}</p>
      </div>
      
      {/* Experience */}
      {data.experiences.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3 text-[#2F69FF]">Experiência Profissional</h2>
          
          {data.experiences.map((exp, index) => (
            <div key={index} className="mb-4">
              <div className="flex flex-col sm:flex-row sm:justify-between mb-1">
                <h3 className="font-medium text-[#FB316E]">{exp.jobTitle}</h3>
                <div className="text-sm text-neutral-600">
                  {exp.startDate && new Date(exp.startDate).toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' })}
                  {' - '}
                  {exp.endDate 
                    ? new Date(exp.endDate).toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' })
                    : 'Atual'}
                </div>
              </div>
              <div className="text-sm font-medium mb-1">{exp.company}</div>
              <p className="text-sm text-neutral-700">{exp.description}</p>
            </div>
          ))}
        </div>
      )}
      
      {/* Education */}
      {data.education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3 text-[#2F69FF]">Formação Acadêmica</h2>
          
          {data.education.map((edu, index) => (
            <div key={index} className="mb-3">
              <div className="flex flex-col sm:flex-row sm:justify-between mb-1">
                <h3 className="font-medium text-[#FB316E]">{edu.degree}</h3>
                <div className="text-sm text-neutral-600">
                  {edu.startDate && new Date(edu.startDate).toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' })}
                  {' - '}
                  {edu.endDate 
                    ? new Date(edu.endDate).toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' })
                    : 'Atual'}
                </div>
              </div>
              <div className="text-sm font-medium">{edu.institution}</div>
            </div>
          ))}
        </div>
      )}
      
      {/* Skills */}
      {data.skills && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2 text-[#2F69FF]">Habilidades</h2>
          <div className="flex flex-wrap gap-2">
            {data.skills.split(',').map((skill, index) => (
              <span 
                key={index} 
                className="px-3 py-1 bg-neutral-100 rounded-full text-sm"
              >
                {skill.trim()}
              </span>
            ))}
          </div>
        </div>
      )}
      
      {/* Languages */}
      {data.languages.length > 0 && data.languages[0].language && (
        <div>
          <h2 className="text-lg font-semibold mb-2 text-[#2F69FF]">Idiomas</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {data.languages.map((lang, index) => (
              lang.language && (
                <div key={index} className="flex justify-between items-center border border-neutral-200 rounded-md px-3 py-2">
                  <span className="font-medium">{lang.language}</span>
                  <span className="text-sm text-neutral-600">{lang.proficiency}</span>
                </div>
              )
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
