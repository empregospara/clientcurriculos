import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { languageSchema } from "@shared/schema";

// Array schema for languages
const languagesSchema = z.array(languageSchema);

// Form schema for skills and languages
const formSchema = z.object({
  skills: z.string(),
  languages: languagesSchema
});

interface SkillsPaymentProps {
  skills: string;
  languages: {
    language: string;
    proficiency: string;
  }[];
  updateSkills: (skills: string) => void;
  updateLanguages: (languages: any[]) => void;
  onPrev: () => void;
  payer_email: string;
  preferenceId: string | null;
  isPaid: boolean;
  isPaymentVerifying: boolean;
  onPaymentProcess: (email: string) => void;
  onPaymentStarted: (id: string) => void;
  onDownloadPDF: () => void;
}

export default function SkillsPayment({
  skills,
  languages,
  updateSkills,
  updateLanguages,
  onPrev,
  payer_email,
  preferenceId,
  isPaid,
  isPaymentVerifying,
  onPaymentProcess,
  onPaymentStarted,
  onDownloadPDF
}: SkillsPaymentProps) {
  
  const { register, control, formState: { errors }, watch } = useForm({
    defaultValues: {
      skills,
      languages: languages.length ? languages : [{ language: "", proficiency: "Básico" }]
    },
    resolver: zodResolver(formSchema)
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "languages"
  });

  const watchedFields = watch();

  // Save field data as it changes
  useEffect(() => {
    updateSkills(watchedFields.skills);
    updateLanguages(watchedFields.languages);
  }, [watchedFields, updateSkills, updateLanguages]);

  const addLanguage = () => {
    append({ language: "", proficiency: "Básico" });
  };

  const handleGenerateResume = () => {
    // Gerar currículo diretamente, sem pagamento
    onDownloadPDF();
  };

  return (
    <div className="step-container animation-fade-in">
      <h2 className="text-2xl font-bold mb-6 text-[#FB316E]">Habilidades e Idiomas</h2>
      
      <form id="skills-form" onSubmit={(e) => e.preventDefault()}>
        <div className="mb-8">
          <div className="form-control relative mb-2">
            <Textarea
              {...register("skills")}
              rows={3}
              className="peer w-full border-2 border-neutral-300 rounded-md px-4 pt-6 pb-3 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
              placeholder=" "
            />
            <label className="absolute text-neutral-600 left-4 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-2">
              Habilidades
            </label>
            {errors.skills && (
              <p className="text-red-500 text-xs mt-1">{errors.skills.message}</p>
            )}
          </div>
          <p className="text-sm text-gray-500 ml-1">Digite suas habilidades separadas por vírgula (ex: Excel, Word, Inglês, Marketing Digital)</p>
        </div>
        
        <div className="mb-8">
          <label className="block text-neutral-700 font-medium mb-2">Idiomas</label>
          <div id="languages-container" className="space-y-4">
            {fields.map((field, index) => (
              <div key={field.id} className="language-item bg-white border-2 border-neutral-100 rounded-md p-4 shadow-sm">
                <div className="flex flex-wrap md:flex-nowrap items-center gap-4">
                  <div className="form-control relative flex-grow w-full md:w-auto">
                    <Input
                      {...register(`languages.${index}.language`)}
                      className="w-full border-2 border-neutral-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                      placeholder="Idioma (ex: Inglês, Espanhol)"
                    />
                    {errors.languages?.[index]?.language && (
                      <p className="text-red-500 text-xs mt-1">{errors.languages[index]?.language?.message as string}</p>
                    )}
                  </div>
                  
                  <div className="form-control relative w-full md:w-48 mt-2 md:mt-0">
                    <Select
                      defaultValue={field.proficiency}
                      onValueChange={(value) => {
                        const event = {
                          target: { value }
                        };
                        register(`languages.${index}.proficiency`).onChange(event as any);
                      }}
                    >
                      <SelectTrigger className="w-full border-2 border-neutral-300 rounded-md h-[42px] focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]">
                        <SelectValue placeholder="Nível de proficiência" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Básico">Básico</SelectItem>
                        <SelectItem value="Intermediário">Intermediário</SelectItem>
                        <SelectItem value="Avançado">Avançado</SelectItem>
                        <SelectItem value="Fluente">Fluente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {index > 0 && (
                    <Button 
                      type="button" 
                      variant="outline"
                      className="text-red-500 hover:text-red-700 border-2 mt-2 md:mt-0 flex items-center"
                      onClick={() => remove(index)}
                    >
                      <span className="material-icons text-sm mr-1">remove_circle</span>
                      Remover
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <Button 
            type="button" 
            variant="ghost"
            onClick={addLanguage}
            className="flex items-center text-[#2F69FF] font-medium mt-4"
          >
            <span className="material-icons text-lg mr-1">add_circle</span>
            Adicionar outro idioma
          </Button>
        </div>
        
        {/* PDF Generation Section */}
        <div className="border-t border-neutral-200 pt-6 mb-6">
          <h4 className="text-xl font-semibold mb-4 text-[#2F69FF]">Gerar Currículo</h4>
          
          <div className="bg-neutral-50 border-2 border-neutral-200 rounded-md p-4 mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-neutral-700 font-medium">Geração de Currículo em PDF</span>
              <span className="font-semibold text-[#2F69FF]">Gratuito</span>
            </div>
            <p className="text-sm text-neutral-600">Clique no botão abaixo para gerar seu currículo em formato PDF profissional seguindo o layout do modelo de exemplo.</p>
          </div>
          
          {/* PDF Preview button */}
          <div id="pdf-preview" className="mb-6">
            <div className="bg-white border-2 border-neutral-200 rounded-md shadow-sm p-5">
              <div className="text-center">
                <svg className="mx-auto h-16 w-16 text-[#2F69FF] mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h4 className="text-lg font-semibold text-neutral-800 mb-2">Finalize seu currículo</h4>
                <p className="text-neutral-600 mb-5 px-4">Revise suas informações e clique no botão abaixo para gerar o PDF do seu currículo.</p>
                <Button 
                  type="button" 
                  id="download-pdf" 
                  className="px-8 py-4 bg-gradient-to-r from-[#FB316E] to-[#2F69FF] text-white rounded-md font-medium hover:opacity-90 transition-opacity shadow-md flex items-center mx-auto"
                  onClick={handleGenerateResume}
                >
                  <span className="material-icons mr-2">download</span>
                  Gerar Currículo PDF
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button 
            type="button" 
            variant="outline"
            onClick={onPrev}
            className="px-6 py-2 border-2 border-neutral-300 text-neutral-700 rounded-md font-medium hover:bg-neutral-50 transition-colors"
          >
            Anterior
          </Button>
        </div>
      </form>
    </div>
  );
}
