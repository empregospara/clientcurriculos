import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { experienceSchema } from "@shared/schema";

// Array schema for experience
const experiencesSchema = z.array(experienceSchema);

interface ExperienceProps {
  data: {
    jobTitle: string;
    company: string;
    startDate: string;
    endDate?: string;
    description: string;
    current?: boolean;
  }[];
  updateData: (data: any) => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function Experience({ data, updateData, onNext, onPrev }: ExperienceProps) {
  const { register, control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      experiences: data.length ? data : [{ 
        jobTitle: "", 
        company: "", 
        startDate: "", 
        endDate: "", 
        description: "", 
        current: false 
      }]
    },
    resolver: zodResolver(z.object({ experiences: experiencesSchema }))
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "experiences"
  });

  const onSubmit = (values: any) => {
    updateData(values.experiences);
    onNext();
  };

  const addExperience = () => {
    append({ 
      jobTitle: "", 
      company: "", 
      startDate: "", 
      endDate: "", 
      description: "", 
      current: false 
    });
  };

  return (
    <div className="step-container animation-fade-in">
      <h2 className="text-2xl font-bold mb-6 text-[#FB316E]">Experiência Profissional</h2>
      
      <form id="experience-form" onSubmit={handleSubmit(onSubmit)}>
        <div id="experience-container">
          {fields.map((field, index) => (
            <div key={field.id} className="experience-item border-2 border-neutral-200 rounded-md p-5 mb-6 shadow-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <div className="form-control relative">
                  <Input
                    {...register(`experiences.${index}.jobTitle`)}
                    className="peer w-full border-2 border-neutral-300 rounded-md px-3 pt-5 pb-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    placeholder=" "
                  />
                  <label className="absolute text-neutral-600 left-3 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-1">Cargo</label>
                  {errors.experiences?.[index]?.jobTitle && (
                    <p className="text-red-500 text-xs mt-1">{errors.experiences[index]?.jobTitle?.message as string}</p>
                  )}
                </div>
                
                <div className="form-control relative">
                  <Input
                    {...register(`experiences.${index}.company`)}
                    className="peer w-full border-2 border-neutral-300 rounded-md px-3 pt-5 pb-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    placeholder=" "
                  />
                  <label className="absolute text-neutral-600 left-3 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-1">Empresa</label>
                  {errors.experiences?.[index]?.company && (
                    <p className="text-red-500 text-xs mt-1">{errors.experiences[index]?.company?.message as string}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <div className="form-control relative">
                  <Input
                    {...register(`experiences.${index}.startDate`)}
                    type="month"
                    className="peer w-full border-2 border-neutral-300 rounded-md px-3 pt-5 pb-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    placeholder=" "
                  />
                  <label className="absolute text-neutral-600 left-3 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-1">Data de Início</label>
                  {errors.experiences?.[index]?.startDate && (
                    <p className="text-red-500 text-xs mt-1">{errors.experiences[index]?.startDate?.message as string}</p>
                  )}
                </div>
                
                <div className="form-control relative">
                  <Input
                    {...register(`experiences.${index}.endDate`)}
                    type="month"
                    className="peer w-full border-2 border-neutral-300 rounded-md px-3 pt-5 pb-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    placeholder=" "
                  />
                  <label className="absolute text-neutral-600 left-3 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-1">Data de Término (ou deixe vazio se atual)</label>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="form-control relative">
                  <Textarea
                    {...register(`experiences.${index}.description`)}
                    rows={3}
                    className="peer w-full border-2 border-neutral-300 rounded-md px-3 pt-5 pb-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    placeholder=" "
                  />
                  <label className="absolute text-neutral-600 left-3 top-4 pointer-events-none transition-all duration-200 peer-focus:text-[#2F69FF] peer-focus:text-xs peer-focus:top-1">Descrição das Atividades</label>
                  {errors.experiences?.[index]?.description && (
                    <p className="text-red-500 text-xs mt-1">{errors.experiences[index]?.description?.message as string}</p>
                  )}
                </div>
              </div>
              
              {index > 0 && (
                <div className="flex justify-end">
                  <Button 
                    type="button" 
                    variant="outline"
                    className="text-red-500 hover:text-red-700 text-sm border-2"
                    onClick={() => remove(index)}
                  >
                    <span className="material-icons text-sm mr-1">remove_circle</span>
                    Remover
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mb-6">
          <Button 
            type="button" 
            variant="ghost"
            onClick={addExperience}
            className="flex items-center text-[#2F69FF] font-medium"
          >
            <span className="material-icons text-lg mr-1">add_circle</span>
            Adicionar outra experiência
          </Button>
        </div>
        
        <div className="flex justify-between">
          <Button 
            type="button" 
            variant="outline"
            onClick={onPrev}
            className="px-6 py-2 border-2 border-neutral-300 text-neutral-700 rounded-md font-medium hover:bg-neutral-50 transition-colors"
          >
            Anterior
          </Button>
          <Button 
            type="submit" 
            className="px-6 py-3 bg-gradient-to-r from-[#FB316E] to-[#2F69FF] text-white rounded-md font-medium hover:opacity-90 transition-opacity shadow-md"
          >
            Próximo
          </Button>
        </div>
      </form>
    </div>
  );
}
