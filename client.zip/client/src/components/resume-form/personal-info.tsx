import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { personalInfoSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface PersonalInfoProps {
  data: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedin?: string;
    profile: string;
  };
  updateData: (data: any) => void;
  onNext: () => void;
}

export default function PersonalInfo({ data, updateData, onNext }: PersonalInfoProps) {
  const form = useForm({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: data,
    mode: "onChange",
  });

  const onSubmit = (values: any) => {
    updateData(values);
    onNext();
  };

  return (
    <div className="step-container animation-fade-in">
      <h2 className="text-2xl font-bold mb-6 text-[#FB316E]">Informações Pessoais</h2>
      
      <Form {...form}>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    Nome Completo
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    Email
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="email"
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-8">
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    Telefone
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="tel"
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    Cidade/Estado
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="linkedin"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    LinkedIn (opcional)
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <div className="text-xs text-gray-500 mt-1 ml-1">
                    Ex: linkedin.com/in/odanielsena/
                  </div>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
          </div>
          
          <div>
            <FormField
              control={form.control}
              name="profile"
              render={({ field }) => (
                <FormItem className="form-control relative">
                  <FormLabel className="text-neutral-600 mb-1 block">
                    Resumo Profissional
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      rows={4}
                      className="w-full border-2 border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2F69FF]/50 focus:border-[#2F69FF]"
                    />
                  </FormControl>
                  <FormMessage className="text-red-500" />
                </FormItem>
              )}
            />
          </div>
          
          <div className="flex justify-end">
            <Button 
              type="button" 
              onClick={form.handleSubmit(onSubmit)}
              className="px-6 py-3 bg-gradient-to-r from-[#FB316E] to-[#2F69FF] text-white rounded-md font-medium hover:opacity-90 transition-opacity shadow-md"
            >
              Próximo
            </Button>
          </div>
        </div>
      </Form>
    </div>
  );
}
