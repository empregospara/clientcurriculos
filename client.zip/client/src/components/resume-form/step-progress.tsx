import { useEffect, useRef } from "react";

interface StepProgressProps {
  currentStep: number;
  totalSteps: number;
}

export default function StepProgress({ currentStep, totalSteps }: StepProgressProps) {
  const progressBarRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (progressBarRef.current) {
      const progressPercentage = ((currentStep - 1) / (totalSteps - 1)) * 100;
      progressBarRef.current.style.width = `${progressPercentage}%`;
    }
  }, [currentStep, totalSteps]);

  const steps = [
    "Informações Pessoais",
    "Experiência",
    "Educação",
    "Habilidades & Pagamento"
  ];

  return (
    <div className="step-progress mb-8 relative">
      {/* Progress bar container */}
      <div className="relative h-2 rounded-full bg-gray-200 mb-8">
        <div 
          ref={progressBarRef}
          className="h-full rounded-full bg-gradient-to-r from-[#FB316E] to-[#2F69FF] transition-all duration-500 ease-in-out"
          style={{ width: "0%" }}
        ></div>
      </div>
      
      {/* Step circles with labels */}
      <div className="flex justify-between">
        {Array.from({ length: totalSteps }).map((_, index) => {
          const stepNumber = index + 1;
          const isActive = stepNumber === currentStep;
          const isCompleted = stepNumber < currentStep;
          
          return (
            <div key={stepNumber} className="flex flex-col items-center w-1/4">
              <div 
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg relative z-20
                  transition-all duration-300 ease-in-out shadow-md
                  ${isActive ? 'bg-[#FB316E] text-white ring-4 ring-[#FB316E]/20' : ''}
                  ${isCompleted ? 'bg-[#2F69FF] text-white' : ''}
                  ${!isActive && !isCompleted ? 'bg-white border-2 border-gray-300 text-gray-400' : ''}
                `}
              >
                {isCompleted ? '✓' : stepNumber}
              </div>
              <span 
                className={`
                  mt-2 text-xs font-medium text-center
                  ${isActive ? 'text-[#FB316E] font-semibold' : ''}
                  ${isCompleted ? 'text-[#2F69FF] font-semibold' : ''}
                  ${!isActive && !isCompleted ? 'text-gray-500' : ''}
                `}
              >
                {steps[index]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
