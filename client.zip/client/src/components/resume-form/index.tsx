import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import StepProgress from "./step-progress";
import PersonalInfo from "./personal-info";
import Experience from "./experience";
import Education from "./education";
import SkillsPayment from "./skills-payment";
import { ResumeData } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { generatePDF } from "@/utils/pdf-generator";

export default function ResumeForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const [resumeData, setResumeData] = useState<Partial<ResumeData>>({
    personalInfo: {
      fullName: "",
      email: "",
      phone: "",
      location: "",
      linkedin: "",
      profile: ""
    },
    experiences: [{ 
      jobTitle: "", 
      company: "", 
      startDate: "", 
      endDate: "", 
      description: "", 
      current: false 
    }],
    education: [{ 
      degree: "", 
      institution: "", 
      startDate: "", 
      endDate: "", 
      current: false 
    }],
    skills: "",
    languages: [{ language: "", proficiency: "Básico" }]
  });
  const [preferenceId, setPreferenceId] = useState<string | null>(null);
  const [isPaid, setIsPaid] = useState(false);
  const [isPaymentVerifying, setIsPaymentVerifying] = useState(false);
  const { toast } = useToast();

  const totalSteps = 4;

  const handleStepChange = (step: number) => {
    if (step > 0 && step <= totalSteps) {
      setCurrentStep(step);
    }
  };

  const updateResumeData = (section: keyof ResumeData, data: any) => {
    setResumeData(prev => ({
      ...prev,
      [section]: data
    }));
  };

  const createPreferenceMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await apiRequest("POST", "/api/criar-preferencia", { email });
      return response.json();
    },
    onSuccess: (data) => {
      setPreferenceId(data.preferenceId);
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Não foi possível criar a preferência de pagamento. Tente novamente.",
        variant: "destructive",
      });
    }
  });

  const checkPaymentMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", "/api/check-payment", { id });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.paid) {
        setIsPaid(true);
        setIsPaymentVerifying(false);
        
        // Properly clear the interval with type safety
        const intervalId = paymentCheckInterval.current;
        if (intervalId !== null) {
          clearInterval(intervalId);
          paymentCheckInterval.current = null;
        }
        
        toast({
          title: "Pagamento aprovado!",
          description: "Seu currículo está pronto para download.",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Não foi possível verificar o status do pagamento. Tente novamente.",
        variant: "destructive",
      });
      setIsPaymentVerifying(false);
    }
  });

  // Using ReturnType to get the exact type of setInterval's return value
  const paymentCheckInterval = { current: null as ReturnType<typeof setInterval> | null };

  const startPaymentVerification = (id: string) => {
    setIsPaymentVerifying(true);
    
    // First check immediately
    checkPaymentMutation.mutate(id);
    
    // Then check every 5 seconds
    paymentCheckInterval.current = setInterval(() => {
      checkPaymentMutation.mutate(id);
    }, 5000);
  };

  const handlePaymentProcess = (email: string) => {
    createPreferenceMutation.mutate(email);
  };

  const handlePaymentStarted = (id: string) => {
    startPaymentVerification(id);
  };

  const handleDownloadPDF = () => {
    if (resumeData.personalInfo) {
      generatePDF(resumeData as ResumeData);
    }
  };

  return (
    <div className="resume-form w-full max-w-4xl mx-auto p-4 sm:p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-center mb-2 bg-gradient-to-r from-[#FB316E] to-[#2F69FF] bg-clip-text text-transparent">
          Crie Seu Currículo Profissional
        </h1>
        <p className="text-center text-gray-600 text-sm sm:text-base">
          Preencha as informações abaixo para gerar seu currículo em formato PDF
        </p>
      </div>
      
      <StepProgress 
        currentStep={currentStep} 
        totalSteps={totalSteps}
      />
      
      <div className="mt-6 sm:mt-8 bg-gray-50 p-4 sm:p-6 rounded-lg border border-gray-200">
        {currentStep === 1 && (
          <PersonalInfo 
            data={resumeData.personalInfo!}
            updateData={(data) => updateResumeData("personalInfo", data)}
            onNext={() => handleStepChange(currentStep + 1)}
          />
        )}
        
        {currentStep === 2 && (
          <Experience 
            data={resumeData.experiences!}
            updateData={(data) => updateResumeData("experiences", data)}
            onNext={() => handleStepChange(currentStep + 1)}
            onPrev={() => handleStepChange(currentStep - 1)}
          />
        )}
        
        {currentStep === 3 && (
          <Education 
            data={resumeData.education!}
            updateData={(data) => updateResumeData("education", data)}
            onNext={() => handleStepChange(currentStep + 1)}
            onPrev={() => handleStepChange(currentStep - 1)}
          />
        )}
        
        {currentStep === 4 && (
          <SkillsPayment 
            skills={resumeData.skills || ""}
            languages={resumeData.languages || []}
            updateSkills={(skills) => updateResumeData("skills", skills)}
            updateLanguages={(languages) => updateResumeData("languages", languages)}
            onPrev={() => handleStepChange(currentStep - 1)}
            payer_email={resumeData.personalInfo?.email || ""}
            preferenceId={preferenceId}
            isPaid={isPaid}
            isPaymentVerifying={isPaymentVerifying}
            onPaymentProcess={handlePaymentProcess}
            onPaymentStarted={handlePaymentStarted}
            onDownloadPDF={handleDownloadPDF}
          />
        )}
      </div>
    </div>
  );
}
