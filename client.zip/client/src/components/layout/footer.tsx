import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link href="/">
              <a className="flex items-center space-x-2">
                <svg className="w-6 h-6 text-[#FB316E]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 0v12h8V4H6z" clipRule="evenodd"></path>
                </svg>
                <span className="text-lg font-semibold">Gerador de Currículos</span>
              </a>
            </Link>
            <p className="text-neutral-400 text-sm mt-2">Crie currículos profissionais em minutos</p>
          </div>
          
          <div className="flex flex-col md:flex-row md:space-x-8">
            <Link href="#">
              <a className="text-neutral-300 hover:text-white mb-2 md:mb-0">Termos de Uso</a>
            </Link>
            <Link href="#">
              <a className="text-neutral-300 hover:text-white mb-2 md:mb-0">Política de Privacidade</a>
            </Link>
            <Link href="#">
              <a className="text-neutral-300 hover:text-white">Contato</a>
            </Link>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-6 pt-6 text-center text-neutral-500 text-sm">
          © {new Date().getFullYear()} Gerador de Currículos. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
