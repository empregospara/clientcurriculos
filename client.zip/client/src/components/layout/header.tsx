import { Link } from "wouter";

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/">
          <a className="flex items-center space-x-2">
            <svg className="w-8 h-8 text-[#FB316E]" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 0v12h8V4H6z" clipRule="evenodd"></path>
            </svg>
            <h1 className="text-xl font-semibold">Gerador de Currículos</h1>
          </a>
        </Link>
        <button className="hidden sm:block text-sm font-medium text-[#2F69FF] hover:text-[#2F69FF]/80">
          Suporte
        </button>
      </div>
    </header>
  );
}
