export interface PersonalInfo {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  profile: string;
}

export interface Experience {
  jobTitle: string;
  company: string;
  startDate: string;
  endDate?: string;
  description: string;
  current?: boolean;
}

export interface Education {
  degree: string;
  institution: string;
  startDate: string;
  endDate?: string;
  current?: boolean;
}

export interface Language {
  language: string;
  proficiency: "Básico" | "Intermediário" | "Avançado" | "Fluente";
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  experiences: Experience[];
  education: Education[];
  skills: string;
  languages: Language[];
}
