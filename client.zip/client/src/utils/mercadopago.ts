// Simplified version - removed all payment functionality as it's no longer needed
// This file is kept to avoid breaking imports in other files

// Functions are now stubs/placeholders
export const initMercadoPago = async () => {
  return Promise.resolve();
};

export const createPaymentPreference = async (email: string) => {
  console.log("Payment system disabled, using free mode");
  return { preferenceId: "free-version" };
};

export const checkPaymentStatus = async (preferenceId: string) => {
  return { paid: true, status: "approved" };
};
