import { ResumeData } from "@shared/schema";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

// Create a temporary DOM element with the ResumeTemplate rendered
const createResumeElement = (data: ResumeData) => {
  // Create a new div element
  const element = document.createElement("div");
  element.id = "temp-resume-for-pdf";
  element.style.position = "absolute";
  element.style.left = "-9999px";
  element.style.top = "-9999px";
  element.style.width = "210mm"; // A4 width
  element.style.fontFamily = "Montserrat, sans-serif";
  
  // Function to format dates as just year
  const formatYear = (dateStr: string) => {
    if (!dateStr) return '';
    return new Date(dateStr).getFullYear().toString();
  };
  
  // Convert skills to array and clean up
  const skillsArray = data.skills
    ? data.skills.split(',').map(skill => skill.trim()).filter(Boolean)
    : [];
  
  // Create skills grid with proper layout and spacing
  const skillsChunks = [];
  for (let i = 0; i < skillsArray.length; i += 3) {
    skillsChunks.push(skillsArray.slice(i, i + 3));
  }
  
  // Inject the HTML content - styled exactly like the reference image
  element.innerHTML = `
    <div id="resumeTemplate" class="bg-white max-w-[210mm] mx-auto" style="font-family: Montserrat, Arial, sans-serif; padding: 30px; color: #333;">
      <!-- Header/Personal Info -->
      <div style="margin-bottom: 25px;">
        <h1 style="font-size: 24px; font-weight: 700; margin-bottom: 4px; color: #4070F4;">${data.personalInfo.fullName}</h1>
        <p style="font-size: 14px; margin-top: 0; margin-bottom: 10px; color: #555;">${data.personalInfo.profile}</p>
        
        <div style="display: flex; flex-wrap: wrap; gap: 25px; font-size: 13px; margin-top: 15px; margin-left: 15px;">
          <div style="display: flex; align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4070F4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; margin-right: 8px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
            <span>${data.personalInfo.phone}</span>
          </div>
          <div style="display: flex; align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4070F4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; margin-right: 8px;"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
            <span>${data.personalInfo.email}</span>
          </div>
          <div style="display: flex; align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4070F4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; margin-right: 8px;"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            <span>${data.personalInfo.location}</span>
          </div>
          ${data.personalInfo.linkedin ? `
          <div style="display: flex; align-items: center;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4070F4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; margin-right: 8px;"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
            <span>${data.personalInfo.linkedin}</span>
          </div>
          ` : ''}
        </div>
      </div>
      
      <!-- About Me Section -->
      <div style="margin-bottom: 25px; position: relative;">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
          <div style="background-color: #4070F4; width: 80px; height: 3px; margin-right: 10px;"></div>
          <h2 style="font-size: 14px; text-transform: uppercase; font-weight: 600; margin: 0;">SOBRE MIM</h2>
        </div>
        <ul style="margin-top: 8px; margin-left: 15px; padding-left: 0; list-style-type: none;">
          <li style="font-size: 14px; position: relative; padding-left: 15px; margin-bottom: 4px;">
            <span style="position: absolute; left: 0; top: 7px; width: 4px; height: 4px; background-color: #666; border-radius: 50%;"></span>
            ${data.personalInfo.profile}
          </li>
        </ul>
      </div>
      
      <!-- Education -->
      ${data.education.length > 0 ? `
        <div style="margin-bottom: 25px; position: relative;">
          <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="background-color: #4070F4; width: 80px; height: 3px; margin-right: 10px;"></div>
            <h2 style="font-size: 14px; text-transform: uppercase; font-weight: 600; margin: 0;">FORMAÇÃO</h2>
          </div>
          
          ${data.education.map((edu) => `
            <div style="margin-bottom: 8px; margin-left: 15px;">
              <div style="font-weight: 600;">${edu.institution}</div>
              <div style="display: flex; justify-content: space-between; font-size: 14px;">
                <div>${edu.degree}</div>
                <div>${formatYear(edu.startDate)} - ${edu.endDate ? formatYear(edu.endDate) : 'Atual'}</div>
              </div>
              <ul style="margin-top: 2px; margin-left: 0; padding-left: 0; list-style-type: none;">
                <li style="font-size: 14px; position: relative; padding-left: 15px; margin-bottom: 2px;">
                  <span style="position: absolute; left: 0; top: 7px; width: 4px; height: 4px; background-color: #666; border-radius: 50%;"></span>
                  ${edu.current === false ? 'Inconcluída' : ''}
                </li>
              </ul>
            </div>
          `).join('')}
        </div>
      ` : ''}
      
      <!-- Experience -->
      ${data.experiences.length > 0 ? `
        <div style="margin-bottom: 25px; position: relative;">
          <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="background-color: #4070F4; width: 80px; height: 3px; margin-right: 10px;"></div>
            <h2 style="font-size: 14px; text-transform: uppercase; font-weight: 600; margin: 0;">EXPERIÊNCIAS</h2>
          </div>
          
          ${data.experiences.map((exp) => `
            <div style="margin-bottom: 10px; margin-left: 15px;">
              <div style="display: flex; justify-content: space-between;">
                <div style="font-weight: 600;">${exp.company}</div>
                <div style="font-size: 14px;">${formatYear(exp.startDate)}</div>
              </div>
              <div style="font-size: 14px; font-style: italic; margin-bottom: 2px;">${exp.jobTitle}</div>
              <ul style="margin-top: 2px; margin-left: 0; padding-left: 0; list-style-type: none;">
                <li style="font-size: 14px; position: relative; padding-left: 15px; margin-bottom: 2px;">
                  <span style="position: absolute; left: 0; top: 7px; width: 4px; height: 4px; background-color: #666; border-radius: 50%;"></span>
                  ${exp.description}
                </li>
              </ul>
            </div>
          `).join('')}
        </div>
      ` : ''}
      
      <!-- Skills -->
      ${skillsArray.length > 0 ? `
        <div style="margin-bottom: 25px; position: relative;">
          <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="background-color: #4070F4; width: 80px; height: 3px; margin-right: 10px;"></div>
            <h2 style="font-size: 14px; text-transform: uppercase; font-weight: 600; margin: 0;">HABILIDADES</h2>
          </div>
          
          <div style="margin-left: 15px; display: flex; flex-wrap: wrap; justify-content: space-between;">
            ${skillsArray.slice(0, 9).map(skill => `
              <div style="flex: 0 0 30%; text-align: center; font-size: 14px; padding: 6px 10px; margin-bottom: 8px;">${skill}</div>
            `).join('')}
          </div>
          
          ${data.languages.length > 0 && data.languages[0].language ? `
            <div style="margin-top: 5px; margin-left: 15px; font-size: 14px;">
              <ul style="margin-top: 2px; margin-left: 0; padding-left: 0; list-style-type: none;">
                <li style="font-size: 14px; position: relative; padding-left: 15px; margin-bottom: 2px;">
                  <span style="position: absolute; left: 0; top: 7px; width: 4px; height: 4px; background-color: #666; border-radius: 50%;"></span>
                  ${data.languages.map(lang => 
                    lang.language ? `${lang.language} ${lang.proficiency}` : ''
                  ).filter(Boolean).join(', ')}
                  ${skillsArray.length > 9 ? ', ' + skillsArray.slice(9).join(', ') : ''}
                </li>
              </ul>
            </div>
          ` : ''}
        </div>
      ` : ''}
      
      <!-- Projects -->
      <div style="margin-bottom: 25px; position: relative;">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
          <div style="background-color: #4070F4; width: 80px; height: 3px; margin-right: 10px;"></div>
          <h2 style="font-size: 14px; text-transform: uppercase; font-weight: 600; margin: 0;">PROJETOS</h2>
        </div>
        
        <div style="margin-left: 15px;">
          <p style="font-size: 14px; font-style: italic; color: #666;">
            Projetos adicionais podem ser incluídos manualmente após o download do PDF.
          </p>
        </div>
      </div>
    </div>
  `;
  
  // Add to DOM
  document.body.appendChild(element);
  
  return element;
};

// Generate PDF from resume data
export const generatePDF = async (data: ResumeData) => {
  try {
    // Create and add the resume element to the DOM
    const resumeElement = createResumeElement(data);
    
    // Wait for fonts to load
    await document.fonts.ready;
    
    // Capture the HTML content as canvas
    const canvas = await html2canvas(resumeElement, {
      scale: 2, // Higher resolution
      useCORS: true,
      logging: false,
    });
    
    // Create PDF (A4 format)
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    const imgWidth = 210; // A4 width in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    // Add the canvas image to the PDF
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    
    // Remove the temporary element
    document.body.removeChild(resumeElement);
    
    // Save the PDF
    pdf.save(`curriculo_${data.personalInfo.fullName.replace(/\s+/g, '_').toLowerCase()}.pdf`);
    
  } catch (error) {
    console.error('Error generating PDF:', error);
    alert('Ocorreu um erro ao gerar o PDF. Por favor, tente novamente.');
  }
};
