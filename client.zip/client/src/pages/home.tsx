import { useEffect } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ResumeForm from "@/components/resume-form";

export default function Home() {
  // Load Google Fonts dynamically
  useEffect(() => {
    const montserratFont = document.createElement("link");
    montserratFont.href = "https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap";
    montserratFont.rel = "stylesheet";
    document.head.appendChild(montserratFont);
    
    const materialIcons = document.createElement("link");
    materialIcons.href = "https://fonts.googleapis.com/icon?family=Material+Icons";
    materialIcons.rel = "stylesheet";
    document.head.appendChild(materialIcons);
    
    return () => {
      document.head.removeChild(montserratFont);
      document.head.removeChild(materialIcons);
    };
  }, []);

  return (
    <div className="flex flex-col min-h-screen font-['Montserrat',sans-serif] bg-neutral-100 text-neutral-800">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-5xl flex-grow">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-6 text-neutral-800">Crie seu currículo profissional</h2>
          <p className="text-neutral-600 mb-8">Preencha o formulário, pague R$2,00 via PIX e obtenha seu currículo em PDF pronto para impressão.</p>
          
          <ResumeForm />
        </div>
      </main>
      <Footer />
    </div>
  );
}
